<?php

/* @author    2codeThemes
*  @package   WPQA/templates/profile
*  @version   1.0
*/

if ( ! defined( 'ABSPATH' ) ) {
   exit; // Exit if accessed directly
}

include wpqa_get_template("head.php","profile/");

include wpqa_get_template("content.php","profile/");?>